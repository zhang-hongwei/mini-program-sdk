"use strict";

exports.projectId = ""; //  项目id
exports.appId = ""; //AppID(小程序ID) scr 2e6050d5442dc5febdde549050bfdaf6
exports.appName = "";
exports.getLocation = false; //默认不获取用户坐标位置
exports.getUserinfo = false; //默认不获取用户头像昵称